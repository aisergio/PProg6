module geomate {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.base;
    requires javafx.graphics;
    requires javafx.web;
    requires javafx.media;
    requires javafx.swing;
    requires static com.google.gson;
    //requires gson;
    //requires junit;
    // Agrega otros módulos JavaFX requeridos si es necesario
    exports geomate; // Exporta el paquete de tu clase principal
}
